﻿using System;

namespace MyCafe
{
    using System;

    // Абстрактный класс для позиций меню ресторана
    public abstract class Meal
    {
        public int weight;
        public int price;

        // Методы, которые должны быть реализованы в производных классах
        public abstract void Init(int _weight, int _price); // Инициализация веса и цены
        public abstract void Read(); // Ввод данных
        public abstract void Display(); // Вывод данных
        public abstract int GetCost(); // Получение пищевой ценности
    }

    // Базовый класс BasicHelper1 для первого вспомогательного изделия
    public class BasicHelper1 : Meal
    {
        public override void Init(int _weight, int _price)
        {
            weight = _weight;
            price = _price;
        }

        public override void Read()
        {
            // Ввод данных с консоли
            Console.Write("Введите массу нетто блюда BasicHelper1: ");
            weight = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите пищевую ценность за 100 грамм продукта BasicHelper1: ");
            price = Convert.ToInt32(Console.ReadLine());
        }

        public override void Display()
        {
            // Вывод данных в консоль
            Console.WriteLine($"Масса нетто блюда BasicHelper1: {weight} грамм");
            Console.WriteLine($"Пищевая ценность на 100 грамм продукта BasicHelper1: {price} калорий");
            Console.WriteLine($"Калорийность блюда BasicHelper1: {GetCost()} калорий");
        }

        public override int GetCost()
        {
            return weight * price;
        }
    }

    // Класс BasicHelper2 для второго вспомогательного блюда
    public class BasicHelper2 : Meal
    {
        // Реализация методов базового класса
        public override void Init(int _weight, int _price)
        {
            weight = _weight;
            price = _price;
        }

        public override void Read()
        {
            Console.Write("Введите массу нетто блюда для BasicHelper2: ");
            weight = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите пищевую ценность за 100 грамм продукта BasicHelper2: ");
            price = Convert.ToInt32(Console.ReadLine());
        }

        public override void Display()
        {
            Console.WriteLine($"Масса нетто блюда BasicHelper2: {weight} грамм");
            Console.WriteLine($"Пищевая ценность на 100 грамм продукта BasicHelper2: {price} калорий");
            Console.WriteLine($"Калорийность блюда BasicHelper2: {GetCost()} калорий");
        }

        public override int GetCost()
        {
            return weight * price;
        }
    }

    // Класс DerivedHelper1 наследует от BasicHelper1 и добавляет новое поле
    public class DerivedHelper1 : BasicHelper1
    {
        public int derivedField1;

        // Инициализация полей базового и производного классов
        public void Init(int _weight, int _price, int _derivedField1)
        {
            base.Init(_weight, _price);
            derivedField1 = _derivedField1;
        }

        // Переопределение метода чтения данных
        public void Read()
        {
            base.Read();
            Console.Write("Введите значение для производного поля 1: ");
            derivedField1 = Convert.ToInt32(Console.ReadLine());
        }

        // Переопределение метода вывода данных
        public void Display()
        {
            base.Display();
            Console.WriteLine($"Производное поле 1: {derivedField1}");
        }

        // Переопределение метода получения калорийности
        public int GetCost()
        {
            return base.GetCost() * derivedField1;
        }
    }

    // Класс DerivedHelper2 наследует от BasicHelper2 и добавляет новое поле
    public class DerivedHelper2 : BasicHelper2
    {
        public int derivedField2;

        public void Init(int _weight, int _price, int _derivedField2)
        {
            base.Init(_weight, _price);
            derivedField2 = _derivedField2;
        }

        public void Read()
        {
            base.Read();
            Console.Write("Введите значение для производного поля 2: ");
            derivedField2 = Convert.ToInt32(Console.ReadLine());
        }

        public void Display()
        {
            base.Display();
            Console.WriteLine($"Производное поле 2: {derivedField2}");
        }

        public int GetCost()
        {
            return base.GetCost() * derivedField2;
        }
    }

    // Класс FirstDerivedMeal представляет первое блюдо, состоящее из двух базовых классов
    public class FirstDerivedMeal : Meal
    {
        public BasicHelper1 helper1 = new BasicHelper1();
        public BasicHelper2 helper2 = new BasicHelper2();

        public override void Init(int _weight, int _price)
        {
            helper1.Init(_weight, _price);
            helper2.Init(_weight, _price);
        }

        public override void Read()
        {
            helper1.Read();
            helper2.Read();
        }

        public override void Display()
        {
            helper1.Display();
            helper2.Display();
        }

        public override int GetCost()
        {
            return helper1.GetCost() + helper2.GetCost();
        }
    }

    // Класс SecondDerivedMeal представляет второе блюдо, состоящее из двух производных классов
    public class SecondDerivedMeal : Meal
    {
        public DerivedHelper1 helper1 = new DerivedHelper1();
        public DerivedHelper2 helper2 = new DerivedHelper2();

        public override void Init(int _weight, int _price)
        {
            helper1.Init(_weight, _price, 2);
            helper2.Init(_weight, _price, 2);
        }

        public override void Read()
        {
            helper1.Read();
            helper2.Read();
        }

        public override void Display()
        {
            helper1.Display();
            helper2.Display();
        }

        public override int GetCost()
        {
            return helper1.GetCost() + helper2.GetCost();
        }
    }

    // Класс ThirdDerivedMeal представляет третье блюдо, состоящее из базового и производного классов
    public class ThirdDerivedMeal : Meal
    {
        public BasicHelper1 helper1 = new BasicHelper1();
        public DerivedHelper2 helper2 = new DerivedHelper2();

        public override void Init(int _weight, int _price)
        {
            helper1.Init(_weight, _price);
            helper2.Init(_weight, _price, 2);
        }

        public override void Read()
        {
            helper1.Read();
            helper2.Read();
        }

        public override void Display()
        {
            helper1.Display();
            helper2.Display();
        }

        public override int GetCost()
        {
            return helper1.GetCost() + helper2.GetCost();
        }
    }

    // Класс MealStore представляет кафе с тремя типами блюд и их количеством
    public class MealStore
    {
        public FirstDerivedMeal meal1 = new FirstDerivedMeal();
        public SecondDerivedMeal meal2 = new SecondDerivedMeal();
        public ThirdDerivedMeal meal3 = new ThirdDerivedMeal();

        public int quantity1;
        public int quantity2;
        public int quantity3;
        public int drinks;

        // Метод для инициализации данных о количестве и стоимости напитков
        public void Init(int _quantity1, int _quantity2, int _quantity3, int _drinks, int _weight1, int _price1, int _weight2, int _price2, int _weight3, int _price3)
        {
            quantity1 = _quantity1;
            quantity2 = _quantity2;
            quantity3 = _quantity3;
            drinks = _drinks;

            meal1.Init(_weight1, _price1);
            meal2.Init(_weight2, _price2);
            meal3.Init(_weight3, _price3);
        }

        // Метод для ввода данных о количестве и стоимости блюд
        public void Read()
        {
            Console.Write("Введите количество первых блюд: ");
            quantity1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество вторых блюд: ");
            quantity2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите количество дессертов: ");
            quantity3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Введите стоимость напитков: ");
            drinks = Convert.ToInt32(Console.ReadLine());

            meal1.Read();
            meal2.Read();
            meal3.Read();
        }

        // Метод для отображения информации о калорийности блюд
        public void Display()
        {
            Console.WriteLine($"Общая калорийность блюд: {(meal1.GetCost() * quantity1) + (meal2.GetCost() * quantity2) + (meal3.GetCost() * quantity3) + drinks} калорий");

            meal1.Display();
            meal2.Display();
            meal3.Display();
        }
    }

    class MyJewelry
    {
        static void Main(string[] args)
        {
            // Создание объекта кафе и инициализация данных
            MealStore MealStore = new MealStore();
            MealStore.Init(10, 20, 30, 500, 40, 500, 35, 120, 55, 200);

            // Ввод данных о количестве и калорийности блюд
            MealStore.Read();

            // Отображение информации о калорийности блюд
            MealStore.Display();

            // Ожидание нажатия клавиши для завершения программы
            Console.ReadKey();
        }
    }

}